package com.example.ntinote.viewModel;

import com.example.ntinote.models.Users;

import java.util.List;

import io.reactivex.Single;

public interface HomeViewModel {

    Single<List<Users>> getAllUsers();

}
