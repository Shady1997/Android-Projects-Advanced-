package com.example.ntinote.repository.impl;

import com.example.ntinote.models.Users;
import com.example.ntinote.repository.HomeRepo;
import com.example.ntinote.webServices.HomeWebServices;

import java.util.List;

import io.reactivex.Single;

public class HomeRepoImpl implements HomeRepo {

    HomeWebServices homeWebServices;

    public HomeRepoImpl(HomeWebServices homeWebServices) {
        this.homeWebServices = homeWebServices;
    }

    @Override
    public Single<List<Users>> getAllUsers() {
        return homeWebServices.getAllUsers();
    }
}
