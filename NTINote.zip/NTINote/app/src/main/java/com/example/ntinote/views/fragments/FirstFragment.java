package com.example.ntinote.views.fragments;


import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.example.ntinote.R;
import com.example.ntinote.models.Users;
import com.example.ntinote.repository.HomeRepo;
import com.example.ntinote.repository.impl.HomeRepoImpl;
import com.example.ntinote.viewModel.HomeViewModel;
import com.example.ntinote.viewModel.impl.HomeViewModelImpl;
import com.example.ntinote.webServices.HomeWebServices;

import java.util.List;

import io.reactivex.Single;

/**
 * A simple {@link Fragment} subclass.
 */
public class FirstFragment extends Fragment {


    Button goBtn;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_one, container, false);
        goBtn = view.findViewById(R.id.btn_go);
        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);



        setUpClickListener();


    }

    private void setUpClickListener() {

        goBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Navigation.findNavController(view).navigate(R.id.action_firstFragment_to_secondFragment);

            }
        });

    }
}
