package com.example.ntinote.webServices;

import com.example.ntinote.models.Users;

import java.util.List;

import io.reactivex.Single;
import retrofit2.http.GET;

public interface HomeWebServices {


    @GET("users")
    Single<List<Users>> getAllUsers();


}
