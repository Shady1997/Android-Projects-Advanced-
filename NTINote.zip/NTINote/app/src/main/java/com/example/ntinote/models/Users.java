package com.example.ntinote.models;

import com.google.gson.annotations.SerializedName;

public class Users {

    @SerializedName("name")
    private String name;
    @SerializedName("username")
    private String userName;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }
}
