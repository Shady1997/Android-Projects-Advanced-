package com.example.ntinote.repository;

import com.example.ntinote.models.Users;

import java.util.List;

import io.reactivex.Single;

public interface HomeRepo {

    Single<List<Users>> getAllUsers();

}
