package com.example.ntinote.viewModel.impl;

import com.example.ntinote.models.Users;
import com.example.ntinote.repository.HomeRepo;
import com.example.ntinote.viewModel.HomeViewModel;

import java.util.List;

import io.reactivex.Single;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.schedulers.Schedulers;

public class HomeViewModelImpl implements HomeViewModel {

    HomeRepo homeRepo;

    public HomeViewModelImpl(HomeRepo homeRepo) {
        this.homeRepo = homeRepo;
    }

    @Override
    public Single<List<Users>> getAllUsers() {
        return homeRepo.getAllUsers()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());
    }
}
